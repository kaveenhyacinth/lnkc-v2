#!/bin/bash

cd ..

zip -r lnkc_api.zip . -x "node_modules/*" -x "dist/*"