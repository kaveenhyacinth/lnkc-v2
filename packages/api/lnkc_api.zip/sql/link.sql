DROP TABLE IF EXISTS t_link CASCADE;

CREATE TABLE t_link (
	-- DEFINITIONS --
	id UUID DEFAULT gen_random_uuid(),
	url TEXT NOT NULL,
	short_code TEXT UNIQUE NOT NULL,
	-- CONSTRAINTS --
	PRIMARY KEY (id)
);

INSERT INTO t_link(url, short_code) VALUES('https://docs.nestjs.com/controllers', 'test1');

SELECT * FROM t_link;