# Lnkc - The URL Shortener

A simple paste and go URL shortener

By Kaveen Hyacinth
